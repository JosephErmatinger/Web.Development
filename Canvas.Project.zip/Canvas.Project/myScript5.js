window.onload = function() {
var video = document.getElementById("video");
var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext('2d');
var i;

video.addEventListener('play', function()  {i=window.setInterval(function() {ctx.drawImage(video, 5, 5, canvas.width, canvas.height);}, 30);}, false);
video.addEventListener('pause',function() {window.clearInterval(i);}, false);
video.addEventListener('ended',function() {clearInterval(i);}, false);
};
function changeImage () {
var image = document.getElementById("bonsai");
if (image.src.match("bonsai2")) {
    image.src = "bonsai.png";
}
else {
	image.src = "bonsai2.jpg";
}}
function changeColorLeft (){
	document.getElementById("leftColumn").style.backgroundColor = "yellow";
}
function changeColorRight(){
	document.getElementById("rightColumn").style.backgroundColor = "green";
}
function changeBox () {
	document.getElementById("box1").innerHTML = "Thanks for visiting!";
}
function changeBox2 (){
	document.getElementById('box2').innerHTML = "Today's date is " + Date();
}
function remove1 (){
	document.getElementById('leftColumn').style.display = "none";
}
function remove2 (){
	document.getElementById('rightColumn').style.display = "none";
	document.getElementById('bonsai').style.display = "block";
	document.getElementById('bonsai').style.margin = "0 auto";
}
function showMessage (){
	alert("Joseph Ermatinger, Week 9 Project Page 5!");
}