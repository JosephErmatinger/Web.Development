window.onload = function() {
var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");

ctx.font ="bold 45px Shojumaru";
ctx.fillStyle = "darkblue";
ctx.textAlign = "center";
ctx.fillText("Japanese Maple", canvas.width/2, canvas.height/2.5);

ctx.font ="bold 45px Press Start 2P";
ctx.lineWidth = "4";
ctx.strokestyle="orange";
ctx.strokeText("Korean Hornbeam", canvas.width/2, 50);

ctx.font ="bold 45px Press Start 2P";
ctx.lineWidth = "4";
ctx.strokeStyle="yellow";
ctx.fillStyle="purple";
ctx.fillText("Ficus", canvas.width/2, 180);
ctx.strokeText("Ficus", canvas.width/2, 180);

ctx.font ="bold 45px Shojumaru";
ctx.lineWidth = "2";
ctx.strokeStyle="orange";
ctx.fillStyle="darkred";
ctx.fillText("Zelkova Serrata", canvas.width/2, 500);
ctx.strokeText("Zelkova Serrata", canvas.width/2, 500);

ctx.font ="bold 75px Shojumaru";
ctx.lineWidth = "6";
ctx.strokeStyle="purple";
var gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
gradient.addColorStop("0"," magenta");
gradient.addColorStop("0.5", "blue");
gradient.addColorStop("1.0", "red");
ctx.fillStyle = gradient;
ctx.fillText("Hinoki Cypress", canvas.width/2, 750);
ctx.strokeText("Hinoki Cypress", canvas.width/2, 750);
};
function changeImage () {
var image = document.getElementById("bonsai");
if (image.src.match("bonsai2")) {
    image.src = "bonsai.png";
}
else {
	image.src = "bonsai2.jpg";
}}
function changeColorLeft (){
	document.getElementById("leftColumn").style.backgroundColor = "yellow";
}
function changeColorRight(){
	document.getElementById("rightColumn").style.backgroundColor = "green";
}
function changeBox () {
	document.getElementById("box1").innerHTML = "Thanks for visiting!";
}
function changeBox2 (){
	document.getElementById('box2').innerHTML = "Today's date is " + Date();
}
function remove1 (){
	document.getElementById('leftColumn').style.display = "none";
}
function remove2 (){
	document.getElementById('rightColumn').style.display = "none";
	document.getElementById('bonsai').style.display = "block";
	document.getElementById('bonsai').style.margin = "0 auto";
}
function showMessage (){
	alert("Joseph Ermatinger, Week 9 Project Page 2!");
}