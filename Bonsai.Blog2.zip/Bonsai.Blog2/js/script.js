window.onload = function() {
var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");

var img = document.getElementById("bonsai");
ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
};
function changeImage () {
var image = document.getElementById("bonsai");
if (image.src.match("images/bonsai2")) {
    image.src = "images/bonsai.png";
}
else {
	image.src = "images/bonsai2.jpg";
}}